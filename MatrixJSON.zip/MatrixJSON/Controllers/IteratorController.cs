﻿using Newtonsoft.Json;
using System.Web.Http;

namespace MatrixJSON.Controllers
{
    //[Consumes("application/json")]
    public class IteratorController : ApiController
    {
        [HttpGet]
        public IHttpActionResult GetData()
        {
            var jsonString = "{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25}";
            var jsonResult = JsonConvert.SerializeObject(jsonString);

            if (jsonResult != null)
            {
                return Ok(jsonResult);
            }
            return NotFound();
        }
        [HttpPost]
        public IHttpActionResult Start()
        {
            var jsonString = "Your Code is here";
            var jsonResult = JsonConvert.SerializeObject(jsonString);

            if (jsonResult != null)
            {
                return Ok(jsonResult);
            }
            return NotFound();
        }
    }
}
